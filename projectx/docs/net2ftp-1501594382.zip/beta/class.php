<?php
class print_books{
			public function books($book){
				while($done = $book->fetch_array(MYSQLI_ASSOC))
				{
					echo "<div class='col-sm-4'>
							<h4>$done[text_book_name]</h4>
							<p><img class='img-responsive' src='img/$done[Branch].jpg' alt='$done[text_book_name]'>
							<h6 class='text'>$done[branch]</h6></p>
							<h6 class='info'>$done[college]</h6>
							<h6 class='text'>$done[rate]</h6>
							<h6 class='text'>$done[email]</h6>
							<h6 class='info'>$done[phone]</h6>
							</div>";
				}
			}
			public function home($book){
				while($done = $book->fetch_array(MYSQLI_ASSOC))
				{
					echo "<div class='box person'>
							<div class='image round'>
								<img src='img/$done[Branch].jpg' alt='$done[text_book_name]'>
							</div>
							<h3> $done[text_book_name] </h3>
							<p> $done[branch]</p>
							</div>";
				}
			}
		};
		$pr_bk=new print_books();
?>