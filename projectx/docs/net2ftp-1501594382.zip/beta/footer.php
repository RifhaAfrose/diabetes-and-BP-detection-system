<footer id='footer'>
	<div class='inner'>
		<div class='flex'>
			<ul class='icons'>
				<li><a href='#' class='icon fa-facebook'><span class='label'>Facebook</span></a></li>
				<li><a href='#' class='icon fa-twitter'><span class='label'>Twitter</span></a></li>
				<li><a href='#' class='icon fa-linkedin'><span class='label'>linkedIn</span></a></li>
				<li><a href='#' class='icon fa-pinterest-p'><span class='label'>Pinterest</span></a></li>
			</ul>
		</div>
	</div>
</footer>