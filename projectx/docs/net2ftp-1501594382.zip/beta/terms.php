<?php
	include_once 'connet.php';
?><html>
	<head>
		<title>EductionForFun.in | Of the Students By the Students For the Students</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
		
	<body>
	<section id="banner">
			<div class="align-left">
				<nav id="nav"><a href="index.html" ><h1><b><font color="#F5FFFA"></a><u>EDUCATIONFORFUN</u></font></b></h1></nav>
				<p>(Exclusive Website Of the students By the students For the students)</p>
				</div>
			</section>
			<header id="header">
				<div class="align-left">
					<nav id="nav">
					<b>
						<a href="index.php"><font size="4" color="red"><div align="left">
						HOME</a>
						<font size="4" color="red"><a href="index.php#news">NEWS</font></a>
						<font size="4" color="red"><a href="index.php#survey">SURVEY</font></a>
						<font size="4" color="red"><a href="index.php#books">BUY | SELL BOOKS</font></a>
						<font size="4" color="red"><a href="index#terms.php">TERMS AND CONDITIONS</font></a>
						</font>
						</b>
						</div>
					</nav>
					<a href="#navPanel" class="navPanelToggle"><span class="fa fa-bars"></span></a>
				</div>
			</header>
			<p align="center"><b><div id="terms"><br><br>
				<p>�	&nbsp;Please read this terms and conditions carefully if you donot wish to bound by these terms and conditions you shouldn�t continue using website. <br><br>
				<p>�	&nbsp;This website is developed by the students for the students just to help students. <br><br>
				<p>�	&nbsp;There is no view of commercial profit in mind we are just developing website for social cause. <br><br>
				<p>�	&nbsp;If you are accessing the website in order to create a social project you agree to all terms and conditions. <br><br>
				<p>�	&nbsp;Terms and conditions may be updated  from time to time. <br><br>
				<p>�	&nbsp;This was not mere one�s idea its the group of students who are working on this project.<br><br>
				<p>�	&nbsp;No one�s identity is revealed for public we have provided you the option to contact us in any situation.<br><br>
				<p>�	&nbsp;Any faults are wrong info provided we take full responsibility.<br><br>
				<p>�	&nbsp;We are not promoting any organisations, colleges, or any other public or private authorities in here.<br><br>
				<p>�	&nbsp;This website is for education purpose not for any other purposes.<br><br>
				<p>�	&nbsp;We have every right on the domain we are using any misuse of the name of domain will be taken action against.<br><br>
			</div>	
<!-- Footer --></b>
			<footer id="footer">
				<div class="inner">
					<div class="flex">
						<ul class="icons">
							<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
							<li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
							<li><a href="#" class="icon fa-pinterest-p"><span class="label">Pinterest</span></a></li>
							<li><a href="#" class="icon fa-vimeo"><span class="label">Vimeo</span></a></li>
						</ul>
					</div>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>