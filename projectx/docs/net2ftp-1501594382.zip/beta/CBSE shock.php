<?php
	include_once 'connet.php';
?><html>
	<head>
		<title>CBSE shocker: Huge errors in totalling board exam marks | EductionForFun.in </title>
		<meta charset='utf-8' />
		<meta name='viewport' content='width=device-width, initial-scale=1' />
		<link rel='stylesheet' href='assets/css/main.css' />
	</head>
		
	<body>
	<!-- Scripts -->
	<script src='assets/js/jquery.min.js'></script>
	<script src='assets/js/skel.min.js'></script>
	<script src='assets/js/util.js'></script>
	<script src='assets/js/main.js'></script>
	<section id='banner'>
		<div class='align-left'>
			<nav id='nav'><a href='index.php' ><h1><b><font color='#F5FFFA'></a><u>EDUCATIONFORFUN</u></font></b></h1></nav>
			<p>(Exclusive Website Of the students By the students For the students)</p>
		</div>
	</section>
		<header id='header'>
			<div class='align-left'>
				<nav id='nav'>
				<b>
					<a href='index.php'><font size='4' color='red'><div align='left'>HOME</a>
					<font size='4' color='red'><a href='index.php#news'>NEWS</font></a>
					<font size='4' color='red'><a href='index.php#survey'>SURVEY</font></a>
					<font size='4' color='red'><a href='index.php#books'>BUY | SELL BOOKS</font></a>
					<font size='4' color='red'><a href='terms.php'>TERMS AND CONDITIONS</font></a>
					</font>
				</b>
					</div>
				</nav>
				<a href='#navPanel' class='navPanelToggle'><span class='fa fa-bars'></span></a>
			</div>
		</header>
		<article><p align='center'><b>NEW DELHI: President Pranab Mukherjee on Saturday inaugurated the much-awaited underground section of the Green Line of Bengaluru\'s Namma Metro train service, a top official said. The underground section will connect Nagasandra in the northern part of the city with Yelachanahalli in the southern part, Bengaluru Metro Rail Corporation Limited (BMRCL) Managing Director Pradeep Singh Kharola said. The commercial operations will be thrown open from Sunday on Reach 4, 4A and the underground section of the 24.2 km Green Line. President of India Pranab Mukherjee flags off Bengaluru\'s Namma Metro train service Seven years ago, then Prime Minister Manmohan Singh laid the foundation stone for the Namma Metro project in Bengaluru with an aim to have hassle-free commute. The section, marking a 12km-stretch, will not only bring south Bengalureans on board, it will allow commuters on the north-south and east-west corridors to switch lines at the Kempegowda-Majestic Interchange. In all, the Metro is expected to cater to at least five lakh people with the complete rollout of the first phase. Residents eager to hop on to the first train will be able to do so around 4pm on Sunday, from Nagasandra. Sandeep B, who used to spend around two hours every day to travel from his home in RBI Layout near JP Nagar to his office at Mahalakshmi Layout, says he can\'t wait to board a metro to work. \"I have been waiting for this day to travel by Metro and save not just time but money too. If I drive my car to office, I would spend Rs 7,000 a month. Sometimes, I would take the office cab just to relax or take calls,\" he says. Thousands of techies from south Bengaluru too are eagerly waiting to travel to Byappanahalli by Metro. \"Now we do not have to endure the Silk Board junction trauma. And we don\'t have to fear the rain either,\" says Sushmit Pal, a techie. \"With metro connectivity through Majestic, we do not need to take our bikes to work anymore and suffer daily stress in the traffic.\" The first phase, which was to be commissioned by December 2010, was delayed by seven years primarily due to two factors - land acquisition that got entangled in litigation and the difficulties of tunnelling through mixed soil conditions.The project also faced opposition in the initial days over axing of trees and razing of heritage and iconic properties. With the resolution of some issues and the passing of time over others, the project has been much awaited to ease the traffic situation in the city.
		</article></b>
		<!-- Footer -->
		<?php include('footer.php')?>
	</body>
</html>