<?php
	require "connet.php";
	include "header.php";
	require "class.php";
	if(isset($_POST['search']))
	{
		$pat=$_POST['pattern'];
		$sql = "SELECT * FROM `user_info` where `text_book_name` like '%$pat%'";
		$aws=$conn->query($sql);
		 $count = mysqli_num_rows($aws);
		 if($count == 1){
			 echo "<h2 class=\"intro-text text-center\">
                        <strong>Showing results for \" $pat \"</strong>
                    </h2>";
					$pr_bk->books($aws);
			}
		else
			echo "<h2 class=\"intro-text text-center\">
                        <strong>No results for \" $pat \"</strong>
                    </h2>";
			echo "<center><a href=\"books.php\"> Go Back </a>";
		}	
		
	include "footer.php";
?>
