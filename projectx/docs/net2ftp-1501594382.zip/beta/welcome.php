<?php
   include('session.php');
   include_once 'connet.php';
?>
<html>
   
   <head>
     <meta charset='UTF-8'>
		<title>EductionForFun</title>
		<meta name='keywords' content='keyword1, keyword2, keyword3'>
		<link rel='stylesheet' href='img/web.css'>
		<link rel='stylesheet' href='img/bootstrap.css'>
		<link rel='stylesheet' href='img/material.min.css'>
		<link rel='shortcut icon' href='img/weblogo1.png' type='image/x-icon'/>		
		<link href='img/style.css' rel='stylesheet' type='text/css'>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="img/material.min.js"></script>
   </head>
   
   <body>
      <h1 style="margin-left: 2%; margin-top: 2%;">Welcome <?php echo $login_session; ?></h1> 
      <h2 align="right"><a href = "logout.php">Sign Out</a></h2>
	  	 <main class="mdl-layout__content ">    
         <div class="mdl-tabs mdl-js-tabs admin-x">
            <div class="mdl-tabs__tab-bar admin-x">
            
               <a href="#tab2-panel" class="mdl-tabs__tab is-active">News</a>
               <a href="#tab3-panel" class="mdl-tabs__tab">Survey</a>
			<a href="#tab6-panel" class="mdl-tabs__tab">Responses</a>
            </div>
          
            <div class="mdl-tabs__panel is-active" id="tab2-panel">
               <form action="new.php" method="post" enctype="multipart/form-data">
				  <div class="form-group">
					<label for="subject">Subject:</label>
					<input type="text" class="form-control" name="subject" placeholder="Subject" required>
				  </div>
				  <div class="form-group">
					<label for="Content">Content</label>
					 <textarea class="form-control" name="content" rows="3" placeholder="Content" required></textarea>
				  </div>
				  <div class="form-group">
				  <input type="text" class="form-control" name="source" placeholder="Source" maxlength="40" required>
				  </div>
				  <button name="submit" type="submit" class="btn btn-default">Submit</button>
				 </form> 
			</div>
            <div class="mdl-tabs__panel" id="tab3-panel">
              <form action="save.php" method="post" enctype="multipart/form-data">
				  <div class="form-group">
					<label for="file">URL:</label>
					<input type="text" name="url" class="form-control" placeholder="Script" required>
				  </div>
				  <label for="Image">Result Image</label>
				  <div class="form-group">
				  <input type="file" class="form-control" name="file" required>
				  </div>
				  <button name="ssubmit" type="submit" class="btn btn-default">Submit</button>
				</form>
            </div>
			 <div class="mdl-tabs__panel" id="tab6-panel">
              
				<center>  <p style="font-size: 2em; font-weight:bold">
				<?php $query3='SELECT * FROM `info`';
				$nposts=$conn->query($query3);
				echo "<table><tr><th> Name</th><th> Subject</th><th>Message</th><th>E-mail</th></tr>";
				while($rows = $nposts->fetch_array(MYSQLI_ASSOC)){
					echo "<tr><td>$rows[name] </td><td>$rows[subject]</td><td>$rows[message]</td><td>$rows[email]</td></tr>";
				}
				echo "<table>";
				?>
				<a href="https://webmail.educationforfun.in"> Click to reply </a>
				</center>
            </div>
         </div>
	  </main>
	</body>
   
</html>