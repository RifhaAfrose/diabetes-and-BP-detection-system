<?php
	include_once 'connet.php';
	require "class.php";
	$books="select * from `user_info` ORDER BY `id` DESC LIMIT 3";
	$book=$conn->query($books);
	$survey = "select * from `survey` ORDER BY `id` DESC LIMIT 2";
	$ssql= $conn->query($survey);
	$row_ssql = $ssql->fetch_array(MYSQLI_ASSOC);
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>EductionForFun.in | Of the Students By the Students For the Students</title>
		<meta charset="utf-8" />
		<link rel="shortcut icon" href="img/logo.png" type="image/x-icon"/>		
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<style>
		#ph {
    padding-top: 0.01cm;
	color="#F5FFFA"
}

</style>
	<?php include "header.php"; ?>
	</head>
		
	<body>
	<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	<!--- Google Analytics --> 
	<script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

		ga('create', 'UA-90388969-1', 'auto');
		ga('send', 'pageview');

	</script>
	<section id="banner">
	<!--<h1 align="left"><B><I><font size="10" color="red"></font></I></B></h1> -->
			<div class="align-left">
				<nav id="nav"><a href="index.html" ><h1><b><font ></a><u><p id="ph">EDUCATIONFORFUN</u><sub>(Exclusive Website Of the students By the students For the students)</sub></p>
				<a href="index.php"><font size="4" color="red">
				<div align="left">
						HOME</a>
						<font size="4" color="red"><a href="index.php#news">&nbsp;&nbsp;NEWS</font></a>
						<font size="4" color="red"><a href="index.php#survey">&nbsp;&nbsp;SURVEY</font></a>
						<font size="4" color="red"><a href="index.php#books">&nbsp;&nbsp;BUY | SELL BOOKS</font></a>
						<font size="4" color="red"><a href="terms.php">&nbsp;&nbsp;TERMS AND CONDITIONS</font></a>
						</font></font></b></h1></nav>
				
				</div>
			</section>

			<header id="header">
				<div class="align-left">
					<nav id="nav">
					<b>
						</b>
						</div>
					</nav>
					<a href="#navPanel" class="navPanelToggle"><span class="fa fa-bars"></span></a>
				</div>
			</header>
			<section id="one" class="wrapper">
				<div class="inner">
					<div  id="news" class="flex flex-3">
						<?php
							$query3='SELECT * FROM `new` ORDER BY `id` DESC LIMIT 3';
							$nposts=$conn->query($query3);
							while($rows = $nposts->fetch_array(MYSQLI_ASSOC)){
							echo "<article>
									<header>
										<h3>$rows[subject]</h3>
									</header>
									<p>
										$rows[short]
									</p>
									<footer>
										<a href='$rows[fname]' class='button special'>More</a>
									</footer>
								  </article>";
							}		
						?>				
					</div>
				</div>
			</section>

		<!-- Two -->
			<section id="two" class="wrapper style1 special">
				<div class="inner">
					<header>
						<h2 id="books">BEST BOOKS AVAILABLE WITH US</h2>
						<p>you can buy any of the below just go to books section</p>
					</header>
					<div class="flex flex-4">
						<?php $pr_bk->home($book); ?>
					</div>
				</div>
				<footer>
					<a href='books.php' class='button special'>More....</a>
				</footer>
			</section>

		<!-- Three -->
			<section id="three" class="wrapper special">
				<div class="inner">
					<header class="align-center">
						<h2>SURVEY AND RESULTS</h2>
					</header>
					<div class="flex flex-2">
						<article>
							<div class="image fit">
								<img src="images/<?php echo $row_ssql['img'] ?>" alt="Pic 01" />
							</div>
							<header>
							</footer>
						</article>
						<article>
							<div class="image fit">
								<h4 id="survey">Attempt a Survey</h4>
					<hr height="50%" width="80%">
					<h3>
						<?php echo $row_ssql['url'] ?>
					</h3>
							</footer>
						</article>
					</div>
				</div>
			</section>

		<!-- Footer -->
			<?php include "footer.php"; ?>

		

	</body>
</html>