<?php
error_reporting(0);
require "init.php";
 
$deleteid = $_POST["deleteid"];
 
$sql = "INSERT INTO `delete_info` (`id`,`deleteid`) VALUES (null,'".$deleteid."');";
if(!mysqli_query($con, $sql)){
    echo '{"message":"Unable to save the data to the database."}';
}
 
?>