<?php
 
error_reporting(0);
 
$db_name = "u210910038_db";
$mysql_user = "u210910038_toor";
$mysql_pass = "Edufun@123";
$server_name = "localhost";
 
$con = mysqli_connect($server_name, $mysql_user, $mysql_pass, $db_name);
 
if(!$con){
    echo '{"message":"Unable to connect to the database."}';
}
 
?>