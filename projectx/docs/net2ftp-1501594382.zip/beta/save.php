<?php
	include_once 'connet.php';
	if(isset($_POST['ssubmit']))
	{
		$url = $_POST['url'];
		$target_dir = "images/";
		$target_file = $target_dir . basename($_FILES['file']['name']);
		$file=$_FILES['file']['name'];
		$sql = "INSERT INTO `survey` (`url`, `img`) VALUES ('$url', '$file')";
		if ($conn->query($sql) === TRUE) {
			echo "<script type='text/javascript'> alert('SURVEY CHANGED!!');</script>";
			include('welcome.php');
			move_uploaded_file($_FILES['file']['tmp_name'],$target_file);
			} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
			}
	}

	if(isset($_POST['submit']))
	{
		$name = $_POST['name'];
		$email = $_POST['email'];
		$sub = $_POST['sub'];
		$msg = $_POST['message'];
		$qq="INSERT INTO `info` (`id`, `name`, `subject`, `message`, `email`) VALUES (NULL ,'".$name."','".$sub."','".$msg."','".$email."')";
		if($conn->query($qq)=== TRUE){
		echo "<script type='text/javascript'> alert('We will get you as soon as possible')</script>";
		include('index.php');
		}
		else{
			echo "<script type='text/javascript'> alert('Something went wrong!! Email support@educationforfun.in ')</script>";
			include('index.php');
		}
	}
?>