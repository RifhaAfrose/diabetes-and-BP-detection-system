<?php
	require "connet.php";
	require "class.php";
	$sql="select * from `user_info`";
        $sql1="select * from `college`";
        $sql2="select * from `branch`";
	$result=$conn->query($sql1);
	$res=$conn->query($sql2);
	$revent=$conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<?php include "header.php"; ?>
<body>
	<div class="container">
		<div class="row">
			<h2 align="center"> Welcome to EduCart </h2>
		</div>
			<div class="row">
				<div class="filter">
					<form action="" method="post">
						<select name="college" class='required'> 
							<option disabled selected> ---- Select college ---- </option>
							<?php				
								while($rows = $result->fetch_array(MYSQLI_ASSOC)){
								echo "<option value='$rows[value]'>$rows[college]</option>";
								}
							?>	
						</select>
						<select name="branch" required> 
							<option disabled selected> **** Choose Branch **** </option>
							<?php				
								while($row = $res->fetch_array(MYSQLI_ASSOC)){
								echo "<option value='$row[value]'>$row[branch]</option>";
								}
							?>	
						</select>
						<input name="Go" type="submit" value="Go">
					</form>
					
				</div>
				<div class="search">
					<form action="search.php" method="post">
						<input type="text" name="pattern" placeholder="Search by book name" required>
						<input name="search" type="submit" value="Search">
					</form>
				</div>
			</div>
			<!-------------- Results ------------->
			<center>
			<div class="row">
				<div class="box">
                <div class="col-lg-12">
                    <hr>
                    <h2 class="intro-text text-center">
                        <strong>Showing results</strong>
                    </h2>
                    <hr>
                </div>
                <?php
					if(!isset($_POST['Go']))
					$pr_bk->books($revent);
					elseif(isset($_POST['college']))
					{
						$a=$_POST['college'];
						$query1="select * from `user_info` where `college`='$a'";
						$aws=$conn->query($query1);
						$pr_bk->books($aws);
					}elseif(isset($_POST['branch']))
					{
						$b=$_POST['branch'];
						$query2="select * from `user_info` where `branch`='$b'";
						$awb=$conn->query($query2);
						$pr_bk->books($awb);
					}elseif(isset($_POST['Go'])&&!isset($_POST['college'])&&!isset($_POST['branch']))
					$pr_bk->books($revent);
					elseif(isset($_POST['Go'])&&isset($_POST['college'])&&isset($_POST['branch']))
					{
						$xa=$_POST['college'];
						$xb=$_POST['branch'];
						$queryx="select * from `user_info` where `branch`='$xb' AND `college`='$xa'";
						$sql2 = "SELECT * FROM `user_info` WHERE `branch`=\'$xb\' and `college` = \'$xa\'";
						$xz=$conn->query($sql2);
						$pr_bk->books($xz);
					}
				?>
                
                <div class="clearfix"></div>
            </div>
			</div>

    </div>
	<div class="container">
		<a class="info" href="index.php"> Return Home </a>
	</div>
	<?php include "footer.php"; ?>
</body>
</html>