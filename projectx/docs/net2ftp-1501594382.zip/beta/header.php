<head>
	<title> Buy Books | Educationforfun.in  </title>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Harshit S K">
	<!-- linking to css and javascript --->
	<link href="img/bootstrap.css" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/main.css" />
	<link rel="shortcut icon" href="img/logo.png" type="image/x-icon"/>		
</head>