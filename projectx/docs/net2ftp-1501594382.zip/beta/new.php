<?php
	include_once 'connet.php';
?>
<?php
	$subs=$_POST['subject'];
	$sub=mysqli_real_escape_string($conn, $subs);
	$fn=substr($subs,0,20).".php";
	$articles=$_POST['content'];
	$article=mysqli_real_escape_string($conn, $articles);
	$source=$_POST['source'];
	$short=substr($article,0,140)."......";
	$fp=fopen($fn,'w');
	$sql = "INSERT INTO `new` (`fname`, `subject`, `content`, `short`, `source`) VALUES ('$fn', '$sub', '$article', '$short','$source')";
	if ($conn->query($sql) === TRUE) {
    echo "<script type='text/javascript'> alert('Inserted!!');</script>";
		include('welcome.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

	
	$content="<?php
	include_once 'connet.php';
?><html>
	<head>
		<title>$sub | EductionForFun.in </title>
		<meta charset='utf-8' />
		<meta name='viewport' content='width=device-width, initial-scale=1' />
		<link rel='shortcut icon' href='img/logo.png' type='image/x-icon'/>		
		<link rel='stylesheet' href='assets/css/main.css' />
	</head>
		
	<body>
	<!-- Scripts -->
	<script src='assets/js/jquery.min.js'></script>
	<script src='assets/js/skel.min.js'></script>
	<script src='assets/js/util.js'></script>
	<script src='assets/js/main.js'></script>
	<section id='banner'>
		<div class='align-left'>
			<nav id='nav'><a href='index.php' ><h1><b><font color='#F5FFFA'></a><u>EDUCATIONFORFUN</u></font></b></h1></nav>
			<p>(Exclusive Website Of the students By the students For the students)</p>
		</div>
	</section>
		<header id='header'>
			<div class='align-left'>
				<nav id='nav'>
				<b>
					<a href='index.php'><font size='4' color='red'><div align='left'>HOME</a>
					<font size='4' color='red'><a href='index.php#news'>NEWS</font></a>
					<font size='4' color='red'><a href='index.php#survey'>SURVEY</font></a>
					<font size='4' color='red'><a href='index.php#books'>BUY | SELL BOOKS</font></a>
					<font size='4' color='red'><a href='terms.php'>TERMS AND CONDITIONS</font></a>
					</font>
				</b>
					</div>
				</nav>
				<a href='#navPanel' class='navPanelToggle'><span class='fa fa-bars'></span></a>
			</div>
		</header>
		<div class='container'><article><p align='center'><b>$articles
		</article></div></b>
		<p class='button special'> $source </p>
		<!-- Footer -->
		<?php include('footer.php')?>
	</body>
</html>";
fwrite($fp, $content);
 
?>