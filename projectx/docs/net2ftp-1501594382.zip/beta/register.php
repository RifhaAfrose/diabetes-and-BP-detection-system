<?php
error_reporting(0);
require "init.php";
 
$id = $_POST["id"];
$name = $_POST["name"];
$text_book_name = $_POST["text_book_name"];
$email = $_POST["email"];
$author = $_POST["author"];
$edition = $_POST["edition"];
$rate = $_POST["rate"];
$phone = $_POST["phone"];
$College = $_POST["College"]; 
$Branch = $_POST["Branch"];
 
$sql = "INSERT INTO `user_info` (`id`,`name`, `text_book_name`, `email`,`author`,`edition`,`rate`,`phone`,`College`,`Branch`) VALUES ('".$id."', '".$name."', '".$text_book_name."', '".$email."','".$author."','".$edition."','".$rate."','".$phone."','".$College."','".$Branch."');";
if(!mysqli_query($con, $sql)){
    echo '{"message":"Unable to save the data to the database."}';
}
 
?>