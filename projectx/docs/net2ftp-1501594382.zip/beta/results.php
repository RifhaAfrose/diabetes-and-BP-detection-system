<?php
	include_once 'connet.php';
?><html>
	<head>
		<title>EductionForFun.in | Of the Students By the Students For the Students</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
		
	<body>
	<section id="banner">
			<div class="align-left">
				<nav id="nav"><a href="index.html" ><h1><b><font color="#F5FFFA"></a><u>EDUCATIONFORFUN</u></font></b></h1></nav>
				<p>(Exclusive Website Of the students By the students For the students)</p>
				</div>
			</section>
			<header id="header">
				<div class="align-left">
					<nav id="nav">
					<b>
						<a href="index.php"><font size="4" color="red"><div align="left">
						HOME</a>
						<font size="4" color="red"><a href="index.php#news">NEWS</font></a>
						<font size="4" color="red"><a href="index.php#survey">SURVEY</font></a>
						<font size="4" color="red"><a href="index.php#books">BUY | SELL BOOKS</font></a>
						<font size="4" color="red"><a href="index#terms.php">TERMS AND CONDITIONS</font></a>
						</font>
						</b>
						</div>
					</nav>
					<a href="#navPanel" class="navPanelToggle"><span class="fa fa-bars"></span></a>
				</div>
			</header>
				<center><h2><b>Enter USN</b></h2>(VTU Results)</center>
				<form action="results.php" method="POST" enctype="multipart/form-data" accept-charset="UTF-8">
	
					<input  type="text" name="usn" required>
					<input  type="submit" value="Submit" >
			<footer id="footer">
				<div class="inner">
					<div class="flex">
						<ul class="icons">
							<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
							<li><a href="#" class="icon fa-linkedin"><span class="label">linkedIn</span></a></li>
							<li><a href="#" class="icon fa-pinterest-p"><span class="label">Pinterest</span></a></li>
							<li><a href="#" class="icon fa-vimeo"><span class="label">Vimeo</span></a></li>
						</ul>
					</div>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>